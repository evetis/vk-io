import parallel from './parallel';
import sequential from './sequential';
import parallelSelected from './parallel-selected';

export { parallel, sequential, parallelSelected };
