import VKError from './error';

export default class SnippetsError extends VKError {}
