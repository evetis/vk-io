import VKError from './error';

export default class UpdatesError extends VKError {}
