import VKError from './error';

export default class UploadError extends VKError {}
