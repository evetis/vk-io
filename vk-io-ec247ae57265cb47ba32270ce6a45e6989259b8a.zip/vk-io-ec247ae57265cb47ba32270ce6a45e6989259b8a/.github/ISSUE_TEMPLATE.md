<!--
	This template is for bug reports.
-->

#### What version of `vk-io` are you using?
<!-- Specify the npm package version, commit hash or branch name -->


#### What version of Node.js are you using?


#### What did you do?


#### What did you expect to happen?


#### What was the actual result?
